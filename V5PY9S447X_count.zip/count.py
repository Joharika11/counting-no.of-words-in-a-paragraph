paragraph = input()
words = paragraph.split()
wordcount = len(words)
print("The number of words in the paragraph = "+ str(wordcount))